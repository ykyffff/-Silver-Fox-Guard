// 全屏警示页逻辑：读取被拦截网址，提供返回/继续访问
const params = new URLSearchParams(location.search);
const url = params.get('url') || '';
const tab = parseInt(params.get('tab') || '0', 10);
const id = parseInt(params.get('id') || '0', 10);

document.getElementById('urlbox').textContent = url;

// 解析理由（后台把理由写到标题场景有限，这里展示通用说明）
const reasons = [
  '域名与知名官方站点高度相似（仿冒手法）',
  '命中银狐钓鱼特征或钓鱼黑名单',
  '可能存在账号密码窃取 / 木马下载风险'
];
const ul = document.getElementById('reasons');
reasons.forEach((r) => {
  const li = document.createElement('li');
  li.textContent = r;
  ul.appendChild(li);
});

document.getElementById('back').onclick = () => {
  if (history.length > 1) history.back();
  else window.close();
};

document.getElementById('proceed').onclick = async () => {
  await new Promise((res) => {
    chrome.runtime.sendMessage({ type: 'proceed', url, tab, id }, () => res());
  });
};
