// 弹出页逻辑：展示当前标签的实时判定与统计
const $ = (id) => document.getElementById(id);
const LEVEL_META = {
  official:   { label: '✓ 官方站点', cls: 'lv-official' },
  safe:       { label: '✓ 安全', cls: 'lv-safe' },
  suspicious: { label: '⚠ 疑似钓鱼', cls: 'lv-suspicious' },
  phishing:   { label: '⛔ 高危钓鱼', cls: 'lv-phishing' }
};

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function render() {
  const tab = await getCurrentTab();
  const host = tab && tab.url ? new URL(tab.url).hostname : '';
  $('host').textContent = host || '（无法获取当前页面）';

  const v = await new Promise((res) => {
    chrome.runtime.sendMessage({ type: 'getVerdictForTab', tabId: tab.id }, (r) => res(r));
  });

  if (!v) {
    $('loading').classList.remove('hidden');
    $('result').classList.add('hidden');
    $('loading').textContent = '本页未触发检测（非网页或已放行）';
    return;
  }

  $('loading').classList.add('hidden');
  $('result').classList.remove('hidden');
  const meta = LEVEL_META[v.level] || LEVEL_META.safe;
  const lv = $('level');
  lv.textContent = meta.label;
  lv.className = 'level ' + meta.cls;
  $('score').textContent = '风险分：' + (v.score || 0) + ' / 100' + (v.brand ? '　仿冒目标：' + v.brand : '');
  const ul = $('reasons');
  ul.innerHTML = '';
  (v.reasons || []).forEach((r) => {
    const li = document.createElement('li');
    li.textContent = r;
    ul.appendChild(li);
  });

  $('btnAllow').onclick = () => rule('userAllow', host);
  $('btnBlock').onclick = () => rule('userBlock', host);
}

async function rule(type, host) {
  if (!host) return;
  await new Promise((res) => chrome.runtime.sendMessage({ type, host }, () => res()));
  render();
}

async function renderStats() {
  const s = await new Promise((res) => chrome.storage.local.get('sf_state_v1', (r) => res(r['sf_state_v1'] || {})));
  const st = s.stats || {};
  $('stats').textContent = `已检 ${st.checked || 0} · 钓鱼 ${st.phishing || 0} · 疑似 ${st.suspicious || 0} · 官网 ${st.official || 0}`;
}

$('openOptions').onclick = (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
};

render();
renderStats();
