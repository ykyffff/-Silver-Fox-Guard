// 设置页逻辑
const $ = (id) => document.getElementById(id);
const KEY = 'sf_state_v1';
let currentState = {}; // 最近一次加载的完整状态（供白名单增删读取 userAllow）
// 白名单 CSV 模板 / 解析 / 校验的共用规则（由 ../lib/allowlistCsv.js 提供，须先于本文件加载）
const WLC = self.SF && self.SF.allowlistCsv;

// AI 供应商预设（OpenAI 兼容 /chat/completions）
const AI_PRESETS = {
  opencodezen: {
    label: 'OpenCode Zen Free（推荐免费）',
    endpoint: 'https://opencode.ai/zen/v1/chat/completions',
    model: 'deepseek-v4.1-flash-free',
    apiKey: '',
    jsonMode: false,
    note: '免费模型带 -free 后缀（deepseek-v4.1-flash-free / glm-5.3-flash-free / mimo-v2.6-flash-free 等）。需在 opencode.ai/auth 获取 API Key 填入下方。免费档偶有调用限制，若返回 403 可换用其他免费端点。'
  },
  ollama: {
    label: 'Ollama 本地模型',
    endpoint: 'http://localhost:11434/v1/chat/completions',
    model: 'llama3',
    apiKey: '',
    jsonMode: true,
    note: '本地运行，零隐私外泄、零费用。需先启动 Ollama 并拉取模型（如 ollama pull llama3）。'
  },
  siliconflow: {
    label: '硅基流动 SiliconFlow',
    endpoint: 'https://api.siliconflow.cn/v1/chat/completions',
    model: 'deepseek-ai/DeepSeek-V3',
    apiKey: '',
    jsonMode: true,
    note: '注册即送额度，填入平台 API Key 即可。'
  },
  qwen: {
    label: '通义千问 Qwen',
    endpoint: 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
    model: 'qwen-plus',
    apiKey: '',
    jsonMode: true,
    note: '阿里云百炼平台，兼容 OpenAI 协议，填入 DASHSCOPE_API_KEY。'
  },
  glm: {
    label: '智谱 GLM',
    endpoint: 'https://open.bigmodel.cn/api/paas/v4/chat/completions',
    model: 'glm-4-flash',
    apiKey: '',
    jsonMode: true,
    note: '智谱开放平台，免费档可用 glm-4-flash，填入 API Key。'
  },
  custom: { label: '自定义', endpoint: '', model: '', apiKey: '', jsonMode: false, note: '' }
};

function detectPreset(ai) {
  for (const [k, p] of Object.entries(AI_PRESETS)) {
    if (k === 'custom') continue;
    if (ai.endpoint && ai.endpoint === p.endpoint) return k;
  }
  return 'custom';
}

function applyPreset(key) {
  const p = AI_PRESETS[key];
  if (!p) return;
  $('aiEndpoint').value = p.endpoint || '';
  $('aiModel').value = p.model || '';
  $('aiApiKey').value = p.apiKey || '';
  $('aiJsonMode').checked = !!p.jsonMode;
  $('providerNote').textContent = p.note || '';
}

async function load() {
  const s = await new Promise((res) => chrome.storage.local.get(KEY, (r) => res(r[KEY] || {})));
  const c = s.config || {};
  const ai = c.ai || {}, whois = c.whois || {};
  const icp = c.icp || {}; // 新增：ICP 配置
  $('mode').value = c.mode || 'block';
  $('warnOnDownload').checked = !!c.warnOnDownload;
  const preset = detectPreset(ai);
  $('aiProvider').value = preset;
  applyPreset(preset);
  $('aiEnabled').checked = !!ai.enabled;
  $('aiEndpoint').value = ai.endpoint || '';
  $('aiApiKey').value = ai.apiKey || '';
  $('aiModel').value = ai.model || '';
  $('aiJsonMode').checked = !!ai.jsonMode;
  $('aiMin').value = ai.minScore != null ? ai.minScore : 35;
  $('aiMax').value = ai.maxScore != null ? ai.maxScore : 85;
  $('whoisEnabled').checked = !!whois.enabled;
  // 加载 ICP 配置（接口盒子：id/key，留空用公共凭证；兼容旧的 apiKey="id,key" 写法）
  $('icpEnabled').checked = icp.enabled !== false;
  let legacyId = '', legacyKey = '';
  if (icp.apiKey) {
    const parts = String(icp.apiKey).split(/[,:：\s]+/).filter(Boolean);
    if (parts.length >= 2) { legacyId = parts[0]; legacyKey = parts[1]; }
  }
  $('icpId').value = icp.id || legacyId || '';
  $('icpKey').value = icp.key || legacyKey || '';
  currentState = s;
  renderBlockList(s);
  renderLog(s);
  loadBuiltinAllow(); // 异步拉取内置白名单后渲染表格
}

async function saveConfig() {
  const s = await new Promise((res) => chrome.storage.local.get(KEY, (r) => res(r[KEY] || {})));
  s.config = s.config || {};
  s.config.mode = $('mode').value;
  s.config.warnOnDownload = $('warnOnDownload').checked;
  s.config.ai = {
    enabled: $('aiEnabled').checked,
    endpoint: $('aiEndpoint').value.trim(),
    apiKey: $('aiApiKey').value.trim(),
    model: $('aiModel').value.trim(),
    jsonMode: $('aiJsonMode').checked,
    minScore: Number($('aiMin').value) || 35,
    maxScore: Number($('aiMax').value) || 85
  };
  s.config.whois = { enabled: $('whoisEnabled').checked };
  s.config.icp = {
    enabled: $('icpEnabled').checked,
    id: $('icpId').value.trim(),
    key: $('icpKey').value.trim()
  };
  await new Promise((res) => chrome.storage.local.set({ [KEY]: s }, () => res()));
  const t = $('saved'); t.classList.remove('hidden'); setTimeout(() => t.classList.add('hidden'), 1500);
}

function renderBlockList(s) {
  const ul = $('blockList'); ul.innerHTML = '';
  (s.userBlock || []).forEach((h) => {
    const li = document.createElement('li');
    li.textContent = h;
    const x = document.createElement('span'); x.className = 'x'; x.textContent = '✕';
    x.onclick = async () => {
      const st = await new Promise((res) => chrome.storage.local.get(KEY, (r) => res(r[KEY] || {})));
      st.userBlock = (st.userBlock || []).filter((i) => i !== h);
      await new Promise((res) => chrome.storage.local.set({ [KEY]: st }, () => res()));
      reloadIntelMsg();
      renderBlockList(st);
    };
    li.appendChild(x);
    ul.appendChild(li);
  });
}

// ---- ④ 白名单管理（可视化浏览） ----
let builtinAllow = [];   // 内置白名单（来自 service worker）

function escapeHtml(t) {
  return String(t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function loadBuiltinAllow() {
  try {
    const res = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'GET_BUILTIN_ALLOWLIST' }, (r) => resolve(r || {}));
    });
    if (res && res.ok && Array.isArray(res.allowlist)) builtinAllow = res.allowlist;
  } catch (e) { console.warn('读取内置白名单失败', e); }
  renderWhitelist($('wl-search').value.trim());
}

// 自定义域名备注（无备注时回退为「（自定义）」，兼容旧数据）
function noteOf(domain) {
  const map = currentState.userAllowNotes || {};
  return map[domain] || '（自定义）';
}

function renderWhitelist(filter) {
  const s = (filter || '').toLowerCase();
  const body = $('wl-body');
  const userAllow = (currentState.userAllow || []).map((d) => ({ domain: d, note: noteOf(d), src: 'user' }));
  const builtin = builtinAllow.map((x) => ({ domain: x.domain, note: x.note || '', src: 'builtin' }));
  let rows = builtin.concat(userAllow);
  if (s) rows = rows.filter((r) => r.domain.toLowerCase().includes(s) || (r.note || '').toLowerCase().includes(s));
  rows.sort((a, b) => a.domain.localeCompare(b.domain));
  $('wl-count').textContent = '共 ' + rows.length + ' 条（内置 ' + builtin.length + ' / 自定义 ' + userAllow.length + '）';
  if (!rows.length) { body.innerHTML = '<tr><td colspan="4" class="muted">无匹配项</td></tr>'; return; }
  body.innerHTML = rows.map((r) => {
    const srcTag = r.src === 'builtin'
      ? '<span class="tag-src builtin">内置</span>'
      : '<span class="tag-src user">自定义</span>';
    // "=" 精确匹配 / "*" 通配：显示时去掉前缀并加标记
    const exact = r.domain.startsWith('=');
    const wild = r.domain.startsWith('*');
    const disp = r.domain.replace(/^[=]+/, '').replace(/^\*\.?/, '');
    const modeTag = exact ? '<span class="tag-src exact">仅本域</span>'
      : (wild ? '<span class="tag-src exact">通配</span>' : '');
    const op = r.src === 'user'
      ? '<span class="del" data-d="' + escapeHtml(r.domain) + '">✕</span>'
      : '<span class="del disabled">—</span>';
    return '<tr><td class="dom">' + escapeHtml(disp) + '</td><td class="src">' + srcTag + modeTag +
      '</td><td>' + escapeHtml(r.note || '') + '</td><td class="src">' + op + '</td></tr>';
  }).join('');
  body.querySelectorAll('.del[data-d]').forEach((el) => {
    el.onclick = () => delAllow(el.getAttribute('data-d'));
  });
}

async function addAllow() {
  // 与批量导入共用 lib/allowlistCsv.js 的规范化 + 校验规则，保证两条入口行为一致
  const vd = WLC.validateDomain($('wl-add-domain').value);
  if (!vd.ok) { alert(vd.reason + '\n\n示例：example.com'); return; }
  const dom = vd.domain;
  const note = $('wl-add-note').value.trim(); // 备注可选，写入 userAllowNotes 供展示/导出
  if (builtinAllow.some((x) => x.domain.toLowerCase() === dom) || (currentState.userAllow || []).includes(dom)) {
    alert('该域名已在白名单中（内置或自定义）'); return;
  }
  const st = await new Promise((res) => chrome.storage.local.get(KEY, (r) => res(r[KEY] || {})));
  st.userAllow = st.userAllow || [];
  st.userAllow.push(dom);
  st.userAllowNotes = st.userAllowNotes || {};
  if (note) st.userAllowNotes[dom] = note; else delete st.userAllowNotes[dom];
  await new Promise((res) => chrome.storage.local.set({ [KEY]: st }, () => res()));
  currentState.userAllow = st.userAllow;
  currentState.userAllowNotes = st.userAllowNotes;
  await reloadIntelMsg();
  $('wl-add-domain').value = ''; $('wl-add-note').value = '';
  renderWhitelist($('wl-search').value.trim());
}

async function delAllow(domain) {
  const st = await new Promise((res) => chrome.storage.local.get(KEY, (r) => res(r[KEY] || {})));
  st.userAllow = (st.userAllow || []).filter((h) => h !== domain);
  if (st.userAllowNotes && st.userAllowNotes[domain] !== undefined) delete st.userAllowNotes[domain];
  await new Promise((res) => chrome.storage.local.set({ [KEY]: st }, () => res()));
  currentState.userAllow = st.userAllow;
  currentState.userAllowNotes = st.userAllowNotes || {};
  await reloadIntelMsg();
  renderWhitelist($('wl-search').value.trim());
}

function reloadIntelMsg() {
  return new Promise((resolve) => {
    try { chrome.runtime.sendMessage({ type: 'RELOAD_INTEL' }, () => resolve()); }
    catch (e) { resolve(); }
  });
}

function exportAllow() {
  const userAllow = (currentState.userAllow || []).map((d) => ({ domain: d, note: noteOf(d), src: 'user' }));
  const builtin = builtinAllow.map((x) => ({ domain: x.domain, note: x.note || '', src: 'builtin' }));
  const rows = builtin.concat(userAllow).sort((a, b) => a.domain.localeCompare(b.domain));
  const header = '域名,来源,备注\n';
  const csv = rows.map((r) => [r.domain, r.src === 'builtin' ? '内置' : '自定义', '"' + (r.note || '').replace(/"/g, '""') + '"'].join(',')).join('\n');
  const blob = new Blob(['\ufeff' + header + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'silverfox-allowlist.csv';
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

function fmtTime(t) {
  const d = new Date(t);
  const p = (n) => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' +
    p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

function renderLog(s) {
  const body = $('log-body');
  const log = s.log || [];
  if (!log.length) {
    body.innerHTML = '<tr><td colspan="4" class="muted">暂无记录</td></tr>';
    return;
  }
  const cls = { phishing: 'phish', suspicious: 'susp', official: 'off', safe: 'safe' };
  body.innerHTML = log.slice(0, 100).map((e) => {
    const tag = '<span class="tag ' + (cls[e.action] || '') + '">' + (e.actionText || e.action) + '</span>';
    return '<tr><td>' + fmtTime(e.t) + '</td><td>' + tag + '</td><td class="h">' + e.host +
      '</td><td class="codes">' + (e.codes || '') + (e.reasons ? '<br>' + e.reasons : '') + '</td></tr>';
  }).join('');
}

function exportLog() {
  chrome.storage.local.get(KEY, (r) => {
    const s = r[KEY] || {};
    const log = s.log || [];
    const header = '时间,动作,域名,命中特征,理由\n';
    const csv = log.map((e) => [
      fmtTime(e.t), e.actionText || e.action, e.host, (e.codes || '').replace(/"/g, '""'),
      '"' + (e.reasons || '').replace(/"/g, '""') + '"'
    ].join(',')).join('\n');
    const blob = new Blob([header + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'silverfox-log.csv';
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  });
}

async function clearLog() {
  if (!confirm('确认清空本地拦截日志？')) return;
  const s = await new Promise((res) => chrome.storage.local.get(KEY, (r) => res(r[KEY] || {})));
  s.log = [];
  await new Promise((res) => chrome.storage.local.set({ [KEY]: s }, () => res()));
  renderLog(s);
}

// 自动保存的控件
['mode', 'warnOnDownload', 'aiEnabled', 'aiEndpoint', 'aiApiKey', 'aiModel',
 'aiJsonMode', 'aiMin', 'aiMax', 'whoisEnabled']
  .forEach((id) => $(id).addEventListener('change', saveConfig));

// 预设切换：非自定义时自动填充端点/模型/说明
$('aiProvider').addEventListener('change', () => {
  const key = $('aiProvider').value;
  if (key === 'custom') { $('providerNote').textContent = '手动填写下方端点与模型。'; return; }
  applyPreset(key);
  saveConfig();
});

$('resetStats').onclick = async () => {
  const s = await new Promise((res) => chrome.storage.local.get(KEY, (r) => res(r[KEY] || {})));
  s.stats = { checked: 0, phishing: 0, suspicious: 0, official: 0 };
  await new Promise((res) => chrome.storage.local.set({ [KEY]: s }, () => res()));
  alert('统计已清空');
};

$('btn-export-log').onclick = exportLog;
$('btn-clear-log').onclick = clearLog;

// ④ 白名单管理：搜索 / 添加 / 导出
$('wl-search').addEventListener('input', (e) => renderWhitelist(e.target.value.trim()));
$('wl-add').addEventListener('click', addAllow);
$('wl-add-domain').addEventListener('keydown', (e) => { if (e.key === 'Enter') addAllow(); });
$('wl-export').addEventListener('click', exportAllow);

// ---- ④ 白名单：批量导入 / CSV 模板下载 ----
// 规则全部来自 lib/allowlistCsv.js：模板与解析器共用同一份 FIELDS / HEADER / csvCell，
// 因此「下载的模板」必定能被「导入解析器」识别。
const SKIP_LABEL = {
  builtinSource: '来源标注为「内置」（内置情报只读，无需导入）',
  dupInFile: '文件内重复（同一域名出现多次）',
  dupUser: '已存在于自定义白名单',
  dupBuiltin: '已被内置白名单覆盖'
};

// 编码自适应解码：UTF-8 → GB18030/GBK 依次尝试，避免 Excel「另存为 CSV」存成 ANSI/GBK 后无法导入
function decodeBytes(buf) {
  const bytes = new Uint8Array(buf);
  // ① 严格 UTF-8（带/不带 BOM 均可，BOM 由解析层剥离）
  try {
    return { text: new TextDecoder('utf-8', { fatal: true }).decode(bytes), enc: 'UTF-8' };
  } catch (e) { /* 不是合法 UTF-8，继续尝试中文 ANSI 编码 */ }
  // ② GB18030 兼容 GBK / GB2312（Excel 中文版默认另存格式）
  for (const enc of ['gb18030', 'gbk']) {
    try {
      const t = new TextDecoder(enc, { fatal: true }).decode(bytes);
      if (t.indexOf('\ufffd') < 0) return { text: t, enc: enc.toUpperCase() };
    } catch (e) { /* 换下一个编码 */ }
  }
  // ③ 兜底：宽松 UTF-8，交由调用方检测替换字符并给出提示
  return { text: new TextDecoder('utf-8').decode(bytes), enc: '' };
}

function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => {
      try { resolve(decodeBytes(fr.result)); }
      catch (e) { resolve({ text: String(fr.result || ''), enc: '' }); }
    };
    fr.onerror = () => reject(new Error('文件读取失败，请重试'));
    fr.readAsArrayBuffer(file);
  });
}

// 下载模板：UTF-8 BOM + 固定表头 + 示例行，与导入识别规则严格一致
function downloadAllowTemplate() {
  const blob = new Blob([WLC.buildTemplate()], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = WLC.TEMPLATE_FILENAME;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// 字段规范表由 FIELDS 动态生成：说明永远与实际解析规则同步，不会脱节
function renderImportSpec() {
  const body = $('wl-spec-body');
  if (!body) return;
  body.innerHTML = WLC.FIELDS.map((f, i) =>
    '<tr><td>' + (i + 1) + '</td><td><b>' + escapeHtml(f.label) + '</b></td>' +
    '<td class="' + (f.required ? 'req' : 'opt') + '">' + (f.required ? '必填' : '可选') + '</td>' +
    '<td>' + escapeHtml(f.format) + '</td><td><code>' + escapeHtml(f.example) + '</code></td>' +
    '<td>' + escapeHtml(f.mapsTo) + '</td></tr>'
  ).join('');
  $('wl-spec-header').textContent = WLC.HEADER;
  $('wl-spec-limits').textContent = '单文件 ≤ ' + Math.round(WLC.MAX_FILE_BYTES / 1024 / 1024) +
    ' MB / ≤ ' + WLC.MAX_DATA_ROWS + ' 行数据';
}

function showImportResult(r) {
  const box = $('wl-import-result');
  box.classList.remove('hidden', 'ok', 'fail');
  if (r.errors.length) box.classList.add('fail');
  else if (r.accepted.length) box.classList.add('ok');

  const html = [];
  html.push('<div class="ir-summary">' +
    '<span class="ok">✓ ' + (r.dryRun ? '校验通过 ' : '成功导入 ') + r.accepted.length + ' 条</span>' +
    '<span class="skip">跳过 ' + r.skipped.length + ' 条</span>' +
    '<span class="err">失败 ' + r.errors.length + ' 条</span>' +
    (r.notesUpdated ? '<span class="ok">更新备注 ' + r.notesUpdated + ' 条</span>' : '') +
    (r.dryRun ? '<span style="color:#2563eb">仅校验模式，未写入任何数据</span>' : '') +
    '</div>');
  if (r.fileEnc && r.fileEnc !== 'UTF-8') {
    html.push('<div class="ir-note">ℹ️ 检测到文件为 ' + escapeHtml(r.fileEnc) +
      ' 编码（常见于 Excel「另存为 CSV」），已自动转码读取，无需手动另存。</div>');
  }

  if (r.accepted.length && !r.dryRun) {
    html.push('<div class="ir-group">已写入自定义白名单并热加载防护情报，下方表格已刷新。</div>');
  }
  if (r.skipped.length) {
    const groups = {};
    r.skipped.forEach((s) => { (groups[s.code] = groups[s.code] || []).push(s.domain); });
    html.push('<div class="ir-group"><b>重复 / 跳过（自动去重，不影响其它行）：</b></div><ul class="ir-list">');
    Object.keys(groups).forEach((k) => {
      const list = groups[k];
      html.push('<li>' + escapeHtml(SKIP_LABEL[k] || k) + ' × ' + list.length + '：' +
        escapeHtml(list.slice(0, 8).join('、')) + (list.length > 8 ? ' …' : '') + '</li>');
    });
    html.push('</ul>');
  }
  if (r.errors.length) {
    html.push('<div class="ir-group"><b>错误明细（以下行未导入，修正后重新选择文件即可）：</b></div><ul class="ir-list">');
    r.errors.slice(0, 20).forEach((e) => {
      html.push('<li>CSV 第 ' + e.line + ' 行：' + escapeHtml(e.text) + '</li>');
    });
    if (r.errors.length > 20) html.push('<li>… 还有 ' + (r.errors.length - 20) + ' 条错误未显示</li>');
    html.push('</ul>');
  }
  if (r.warnings.length) {
    html.push('<div class="ir-group"><b>提醒：</b></div><ul class="ir-list">');
    r.warnings.slice(0, 10).forEach((w) => {
      html.push('<li>CSV 第 ' + w.line + ' 行：' + escapeHtml(w.text) + '</li>');
    });
    html.push('</ul>');
  }
  if (r.noteRows) {
    html.push('<div class="ir-note">ℹ️ 有 ' + r.noteRows + ' 行填写了「备注」，已随域名一并保存，白名单表格与「导出 CSV」都会带上。</div>');
  }
  if (r.missingOptional && r.missingOptional.length) {
    html.push('<div class="ir-note">ℹ️ 文件缺少可选列：' + escapeHtml(r.missingOptional.join('、')) + '，已按缺省值处理，不影响导入。</div>');
  }
  if (!r.accepted.length && !r.errors.length && r.skipped.length) {
    if (r.notesUpdated) {
      html.push('<div class="ir-note">ℹ️ 域名均已存在，跳过添加；其中 ' + r.notesUpdated +
        ' 条的备注已按文件内容更新。</div>');
    }
    const onlyBuiltin = r.skipped.every((s) => s.code === 'builtinSource');
    html.push('<div class="ir-note">没有新域名需要导入（全部为重复项或内置项）。' +
      (onlyBuiltin ? ' 本文件「来源」列全部标为「内置」，内置条目只读、会被跳过；' +
        '自定义域名请把「来源」留空或填「自定义」。' : '') + '</div>');
  }
  if (!r.accepted.length && !r.errors.length && !r.skipped.length) {
    html.push('<div class="ir-note">文件中没有可导入的数据行。</div>');
  }
  box.innerHTML = html.join('');
}

function importFail(msg) {
  const box = $('wl-import-result');
  box.classList.remove('hidden', 'ok');
  box.classList.add('fail');
  box.innerHTML = '<div class="ir-summary"><span class="err">✗ 导入失败</span></div><div>' +
    escapeHtml(msg) + '</div>';
}

async function importAllowlist() {
  const fileInput = $('wl-file');
  const file = fileInput.files && fileInput.files[0];
  const dryRun = $('wl-import-dry').checked;

  // ① 文件级格式校验
  if (!file) { importFail('请先选择 .csv 文件；可点「下载 CSV 模板」获取标准格式。'); return; }
  if (!/\.csv$/i.test(file.name)) { importFail('仅支持 .csv 文件，当前选择：' + file.name); return; }
  if (file.size > WLC.MAX_FILE_BYTES) {
    importFail('文件过大（' + (file.size / 1024 / 1024).toFixed(1) + ' MB），上限 ' +
      Math.round(WLC.MAX_FILE_BYTES / 1024 / 1024) + ' MB，请拆分后分批导入。'); return;
  }

  let decoded;
  try { decoded = await readFileAsText(file); }
  catch (e) { importFail(e.message || '文件读取失败'); return; }
  const text = decoded.text;
  const fileEnc = decoded.enc;
  if (typeof text !== 'string' || text.indexOf('\ufffd') >= 0) {
    importFail('检测到无法解码的字符：文件可能是 UTF-16 或被加密/损坏。请用 Excel/WPS 打开后「另存为 → CSV UTF-8」再重试。'); return;
  }

  // ② CSV 解析 + 表头校验（按表头名定位，允许列顺序不同 / 可选列缺省）
  const parsed = WLC.parse(text);
  if (parsed.error) { importFail(parsed.error); return; }
  const records = parsed.records.filter((r) => !WLC.isBlankRow(r.cells));
  if (!records.length) { importFail('文件为空或只含空行。'); return; }

  const mapped = WLC.mapHeader(records[0].cells);
  if (mapped.error) { importFail(mapped.error); return; }
  const idx = mapped.idx;
  const dataRows = records.slice(1);
  if (dataRows.length > WLC.MAX_DATA_ROWS) {
    importFail('数据行共 ' + dataRows.length + ' 条，超过上限 ' + WLC.MAX_DATA_ROWS + ' 条，请拆分文件。'); return;
  }

  // ③ 逐行校验 + 重复数据处理（与「添加放行」共用同一套域名规范化/校验）
  const accepted = [], skipped = [], errors = [], warnings = [], acceptedNotes = {}, updatedNotes = {};
  const seen = new Set();
  const existing = (currentState.userAllow || []).map((d) => String(d).toLowerCase());
  const builtinSet = new Set(builtinAllow.map((x) => String(x.domain || '').toLowerCase()));
  const blockSet = new Set((currentState.userBlock || []).map((d) => String(d).toLowerCase()));
  let noteRows = 0;

  dataRows.forEach((rec) => {
    const c = rec.cells;
    const rawDomain = idx.domain >= 0 ? c[idx.domain] : '';

    // 先解析「来源」：标注为「内置」的行属于只读情报，直接跳过。
    // 这样内置情报中的 =github.io / *.example.com 等前缀写法回导时不会被误判为格式错误，
    // 保证「导出 CSV → 修改 → 导回」零错误闭环。
    let source = WLC.SOURCE_USER;
    if (idx.source >= 0) {
      const rawSrc = c[idx.source];
      if (String(rawSrc == null ? '' : rawSrc).trim() !== '') {
        const ns = WLC.normalizeSource(rawSrc);
        if (!ns.ok) { errors.push({ line: rec.line, text: ns.reason }); return; }
        source = ns.value;
      }
    }
    const rowNote = idx.note >= 0 ? String(c[idx.note] == null ? '' : c[idx.note]).trim() : '';
    if (rowNote) noteRows++;
    if (source === WLC.SOURCE_BUILTIN) {
      skipped.push({ line: rec.line, code: 'builtinSource', domain: String(rawDomain || '').trim() || '(空)' });
      return;
    }

    const vd = WLC.validateDomain(rawDomain);
    if (!vd.ok) {
      const got = String(rawDomain == null ? '' : rawDomain).trim();
      errors.push({ line: rec.line, text: vd.reason + (got ? '（收到：' + got.slice(0, 60) + '）' : '') });
      return;
    }
    const d = vd.domain;

    if (seen.has(d)) { skipped.push({ line: rec.line, code: 'dupInFile', domain: d }); return; }
    seen.add(d);
    if (existing.includes(d)) {
      // 已在自定义白名单：不重复添加，但备注有变化时自动更新（便于重复导入修正备注）
      const curNote = (currentState.userAllowNotes || {})[d] || '';
      if (rowNote && rowNote !== curNote) { updatedNotes[d] = rowNote; }
      skipped.push({ line: rec.line, code: 'dupUser', domain: d });
      return;
    }
    if (builtinSet.has(d)) { skipped.push({ line: rec.line, code: 'dupBuiltin', domain: d }); return; }
    if (blockSet.has(d)) {
      warnings.push({ line: rec.line, text: d + ' 同时存在于「手动拉黑」，放行与拉黑规则可能冲突' });
    }
    accepted.push(d);
    if (rowNote) acceptedNotes[d] = rowNote;
  });

  // ④ 单次写入 storage（避免逐条写），与手动添加一致地热加载情报并刷新表格
  const notesToWrite = Object.assign({}, acceptedNotes, updatedNotes);
  const notesUpdated = Object.keys(updatedNotes).length;
  if (!dryRun && (accepted.length || notesUpdated)) {
    const st = await new Promise((res) => chrome.storage.local.get(KEY, (r) => res(r[KEY] || {})));
    st.userAllow = (st.userAllow || []).concat(accepted);
    // 备注随域名一起保存（仅用于展示/导出，不参与匹配）
    st.userAllowNotes = st.userAllowNotes || {};
    Object.keys(notesToWrite).forEach((k) => { st.userAllowNotes[k] = notesToWrite[k]; });
    await new Promise((res) => chrome.storage.local.set({ [KEY]: st }, () => res()));
    currentState.userAllow = st.userAllow;
    currentState.userAllowNotes = st.userAllowNotes;
    await reloadIntelMsg();
    renderWhitelist($('wl-search').value.trim());
    fileInput.value = ''; // 清空选择，允许重复导入同一文件
  }

  // ⑤ 结果反馈
  showImportResult({
    accepted, skipped, errors, warnings, dryRun, noteRows, notesUpdated,
    missingOptional: mapped.missingOptional, fileEnc
  });
}

$('wl-template').addEventListener('click', downloadAllowTemplate);
$('wl-import').addEventListener('click', importAllowlist);
renderImportSpec();

load();
