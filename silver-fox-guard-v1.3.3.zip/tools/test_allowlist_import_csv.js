/**
 * 用扩展自身的解析器（lib/allowlistCsv.js）实测导入 CSV
 * 验证：表头识别、逐行域名/来源校验、文件内去重、备注列为纯官网名称
 */
const fs = require('fs');
const path = require('path');

const CSV = process.argv[2] || 'C:\\Users\\Administrator\\Desktop\\silverfox-allowlist-import.csv';
require(path.join(__dirname, '..', 'lib', 'allowlistCsv.js'));

const W = global.SF.allowlistCsv;
let fail = 0;
function ok(c, m) { if (c) { console.log('  OK   ' + m); } else { console.log('  FAIL ' + m); fail++; } }

const raw = fs.readFileSync(CSV, 'utf8');
console.log('=== 解析 ' + path.basename(CSV) + ' ===');

ok(raw.charCodeAt(0) === 0xFEFF, 'UTF-8 BOM 存在');

// 1) CSV 解析
const p = W.parse(raw);
ok(!p.error, 'CSV 解析无错误: ' + (p.error || '无'));
const recs = p.records || [];
ok(recs.length > 0, '解析出记录 ' + recs.length + ' 条');

// 2) 表头识别
const hdr = W.mapHeader(recs[0].cells);
ok(!hdr.error, '表头识别成功: ' + (hdr.error || '无错误'));
const idx = hdr.idx;
ok(idx && idx.domain >= 0, '「域名」列 index=' + (idx && idx.domain));
ok(idx && idx.source >= 0, '「来源」列 index=' + (idx && idx.source));
ok(idx && idx.note >= 0, '「备注」列 index=' + (idx && idx.note));

const data = recs.slice(1);
let bad = 0, badList = [], srcBad = 0, srcList = [], emptyNote = 0, noSite = 0;
const seen = new Set(), dup = [];
data.forEach(function (rec) {
  const c = rec.cells;
  const dom = c[idx.domain];
  const src = c[idx.source];
  const note = c[idx.note];
  const vd = W.validateDomain(dom);
  if (!vd.ok) { bad++; if (badList.length < 8) badList.push('第' + rec.line + '行 "' + dom + '" -> ' + vd.reason); }
  else { if (seen.has(vd.domain)) dup.push(vd.domain); seen.add(vd.domain); }
  const ns = W.normalizeSource(src);
  if (!ns.ok) { srcBad++; if (srcList.length < 5) srcList.push('第' + rec.line + '行 "' + src + '" -> ' + ns.reason); }
  if (!String(note || '').trim()) emptyNote++;
  if (!String(note || '').trim()) noSite++;
});
ok(bad === 0, '域名校验全部通过' + (bad ? '，失败 ' + bad + ' 条: ' + badList.join(' | ') : ''));
ok(srcBad === 0, '来源枚举全部合法' + (srcBad ? '，失败: ' + srcList.join(' | ') : ''));
ok(dup.length === 0, '文件内无重复域名' + (dup.length ? '，重复: ' + dup.join(', ') : ''));
ok(emptyNote === 0, '每行均有备注' + (emptyNote ? '，空备注 ' + emptyNote + ' 行' : ''));
ok(noSite === 0, '每行备注均非空（纯官网名称）' + (noSite ? '，缺失 ' + noSite + ' 行' : ''));

// 3) 备注样例
console.log('  备注样例:');
data.slice(0, 3).forEach(function (r) { console.log('    ' + r.cells[idx.note].slice(0, 130)); });

// 4) 分类统计
const cats = {};
data.forEach(function (r) {
  const m = String(r.cells[idx.note]).match(/类别：([^；]+)/);
  const k = m ? m[1] : '未标注';
  cats[k] = (cats[k] || 0) + 1;
});
console.log('  类别分布:', JSON.stringify(cats, null, 0));

// 5) 待核实统计
const pend = data.filter(function (r) { return /待核实/.test(r.cells[idx.note]); }).length;
console.log('  待核实条目:', pend, '（占 ' + Math.round(pend / data.length * 100) + '%）');

// 6) 域名全部通过导入器正则（与模板一致）
ok(data.every(function (r) { return /^[a-z0-9.-]+\.[a-z]{2,}$/i.test(r.cells[idx.domain]); }),
   '全部域名符合模板正则 ^[a-z0-9.-]+\\.[a-z]{2,}$');

console.log(fail === 0 ? '\n✅ 全部通过' : '\n❌ 失败 ' + fail + ' 项');
process.exit(fail === 0 ? 0 : 1);
