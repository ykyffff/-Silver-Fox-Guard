#!/usr/bin/env python3
# 生成扩展图标：盾牌 + 对勾（纯标准库，无需 PIL）
import zlib, struct, math, os

OUT = os.path.join(os.path.dirname(__file__), '..', 'icons')

def write_png(path, size, px):
    raw = b''.join(b'\x00' + row for row in px)
    comp = zlib.compress(raw, 9)
    def chunk(typ, data):
        return struct.pack('>I', len(data)) + typ + data + struct.pack('>I', zlib.crc32(typ + data) & 0xffffffff)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n')
        f.write(chunk(b'IHDR', struct.pack('>IIBBBBB', size, size, 8, 6, 0, 0, 0)))
        f.write(chunk(b'IDAT', comp))
        f.write(chunk(b'IEND', b''))

def lerp(a, b, t):
    return tuple(round(a[i] + (b[i]-a[i])*t) for i in range(3))

def shield_inside(nx, ny):
    if ny < 0.06 or ny > 0.94: return False
    if ny <= 0.62:
        left, right = 0.18, 0.82
    else:
        t = (ny - 0.62) / (0.94 - 0.62)
        left = 0.18 + t * 0.32
        right = 0.82 - t * 0.32
    return left <= nx <= right

def dist_to_seg(px, py, x1, y1, x2, y2):
    dx, dy = x2-x1, y2-y1
    if dx == 0 and dy == 0: return math.hypot(px-x1, py-y1)
    t = max(0, min(1, ((px-x1)*dx + (py-y1)*dy) / (dx*dx + dy*dy)))
    return math.hypot(px-(x1+t*dx), py-(y1+t*dy))

def make(size):
    top = (59, 130, 246)   # #3b82f6
    bot = (29, 78, 216)    # #1d4ed8
    rows = []
    for y in range(size):
        row = bytearray()
        ny = y / (size - 1)
        for x in range(size):
            nx = x / (size - 1)
            r = g = b = 0
            a = 0
            if shield_inside(nx, ny):
                col = lerp(top, bot, ny)
                r, g, b = col
                a = 255
                # 白色对勾（距离使用归一化坐标，厚度也用归一化单位）
                thick = 0.075
                d1 = dist_to_seg(nx, ny, 0.36, 0.50, 0.47, 0.62)
                d2 = dist_to_seg(nx, ny, 0.47, 0.62, 0.70, 0.32)
                if min(d1, d2) < thick:
                    r, g, b, a = 255, 255, 255, 255
            row += bytes((r, g, b, a))
        rows.append(bytes(row))
    return rows

if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    for s in (16, 48, 128):
        write_png(os.path.join(OUT, f'icon{s}.png'), s, make(s))
        print('wrote icon%d.png' % s)
