#!/usr/bin/env node
// 白名单 CSV 模板 / 解析器自测
// 运行：node tools/test_allowlist_csv.js
// 覆盖：模板往返一致性、与现有「导出 CSV」格式兼容、BOM/CRLF 容错、引号转义、
//       表头别名与列顺序、域名规范化与校验、来源枚举、错误行号定位。
// 纯逻辑测试，不需要浏览器或 chrome API。
const path = require('path');
require(path.join(__dirname, '..', 'lib', 'allowlistCsv.js'));
const W = global.SF.allowlistCsv;

let passed = 0, failed = 0;
function ok(name, cond, detail) {
  if (cond) { passed++; console.log('  PASS  ' + name); }
  else { failed++; console.log('  FAIL  ' + name + (detail ? '  → ' + detail : '')); }
}
function eq(name, actual, expected) {
  ok(name, JSON.stringify(actual) === JSON.stringify(expected),
    '实际=' + JSON.stringify(actual) + ' 期望=' + JSON.stringify(expected));
}

console.log('\n[1] 模板定义与生成');
ok('表头固定为 域名,来源,备注', W.HEADER === '域名,来源,备注', W.HEADER);
ok('字段顺序 = 域名/来源/备注', W.FIELDS.map((f) => f.label).join(',') === W.HEADER);
ok('仅「域名」为必填', W.FIELDS.filter((f) => f.required).length === 1 && W.FIELDS[0].required);
const tpl = W.buildTemplate();
ok('模板以 UTF-8 BOM 开头', tpl.charCodeAt(0) === 0xFEFF);
ok('模板文件名正确', W.TEMPLATE_FILENAME === 'silverfox-allowlist-template.csv');
const tplParsed = W.parse(tpl);
ok('模板解析无错误', tplParsed.error === '', tplParsed.error);
eq('模板表头行', tplParsed.records[0].cells, ['域名', '来源', '备注']);
ok('模板含 3 行示例数据', tplParsed.records.length === 4, String(tplParsed.records.length));
tplParsed.records.slice(1).forEach((r, i) => {
  ok('示例行 ' + (i + 1) + ' 可直接导入', W.validateDomain(r.cells[0]).ok, r.cells[0]);
});

console.log('\n[2] 模板 ↔ 解析器往返一致性（核心：下载必能识别）');
const mapped = W.mapHeader(tplParsed.records[0].cells);
ok('模板表头可被识别', mapped.error === '', mapped.error);
eq('列下标映射', mapped.idx, { domain: 0, source: 1, note: 2 });
const roundTrip = W.parse(W.toCSV(tplParsed.records.map((r) => r.cells)));
eq('toCSV → parse 往返无损', roundTrip.records.map((r) => r.cells), tplParsed.records.map((r) => r.cells));

console.log('\n[3] 与现有「导出 CSV」(exportAllow) 格式兼容');
const exported = '\ufeff' + '域名,来源,备注\n' +
  '12306.cn,内置,"铁路 12306"\n' +
  '=github.io,内置,"UGC 平台，仅根域"\n' +
  'my.example.com,自定义,"（自定义）"\n';
const ex = W.parse(exported);
ok('导出文件解析无错误', ex.error === '', ex.error);
eq('导出首行表头', ex.records[0].cells, ['域名', '来源', '备注']);
eq('含逗号备注正确保留', ex.records[2].cells[2], 'UGC 平台，仅根域');
ok('导出表头可识别', W.mapHeader(ex.records[0].cells).error === '');
eq('内置精确前缀行按来源跳过（不误判格式）',
  W.normalizeSource(ex.records[2].cells[1]).value, W.SOURCE_BUILTIN);

console.log('\n[4] CSV 语法容错');
ok('CRLF 换行可解析', W.parse('\ufeff域名,来源,备注\r\na.com,自定义,"x"\r\nb.com,自定义,"y"\r\n').records.length === 3);
ok('末尾无换行可解析', W.parse('域名,来源,备注\na.com,自定义,x').records.length === 2);
ok('空行可用 isBlankRow 过滤', W.isBlankRow(['', '', '  ']) === true && W.isBlankRow(['a.com']) === false);
const q = W.parse('域名,来源,备注\na.com,自定义,"含,逗号和""引号"\n').records[1];
eq('字段内逗号 + 双引号转义', q.cells[2], '含,逗号和"引号');
const multi = W.parse('域名,来源,备注\na.com,自定义,"第一行\n第二行"\nb.com,自定义,z\n');
ok('字段内换行不拆错记录', multi.records.length === 3 && multi.records[1].cells[2] === '第一行\n第二行');
eq('字段内换行后的物理行号正确', multi.records[2].line, 4);
ok('未闭合引号明确报错', W.parse('域名,来源,备注\na.com,自定义,"未闭合').error.includes('未闭合'));

console.log('\n[5] 表头识别（按名称映射，容忍顺序/别名/缺省）');
const m2 = W.mapHeader(['备注', '来源', 'domain']);
ok('列顺序不同 + 英文别名可识别', m2.error === '', m2.error);
eq('乱序列下标', m2.idx, { domain: 2, source: 1, note: 0 });
const m3 = W.mapHeader(['\ufeff 域名 ']);
ok('BOM + 空格可识别，可选列允许缺省', m3.error === '' && m3.idx.domain === 0);
eq('缺省可选列提示', m3.missingOptional, ['来源', '备注']);
ok('缺少「域名」列给出明确错误', W.mapHeader(['主机', '备注']).error.includes('未识别到「域名」列'));
ok('错误提示包含推荐表头', W.mapHeader(['主机']).error.includes('域名,来源,备注'));

console.log('\n[6] 域名规范化与校验（与「添加放行」同一套规则）');
eq('大写 + 空格', W.normalizeDomain('  Example.COM  '), 'example.com');
eq('带 https:// 与路径', W.normalizeDomain('https://Sub.Example.com/login?a=1'), 'sub.example.com');
eq('带 http:// 与路径', W.normalizeDomain('http://Example.COM/a/b'), 'example.com');
ok('合法域名通过', W.validateDomain('oa.example.cn').ok);
ok('带协议的合法域名通过', W.validateDomain('https://Example.com/path').domain === 'example.com');
ok('空值报错 EMPTY', W.validateDomain('   ').code === 'EMPTY');
ok('=精确前缀报错 PREFIX', W.validateDomain('=github.io').code === 'PREFIX');
ok('*通配前缀报错 PREFIX', W.validateDomain('*.example.com').code === 'PREFIX');
ok('无顶级域报错', W.validateDomain('localhost').ok === false);
ok('含非法字符报错', W.validateDomain('exa mple.com').ok === false);
ok('含端口报错', W.validateDomain('example.com:8080').ok === false);
ok('连续点报错', W.validateDomain('a..com').ok === false);
ok('IP 直连被拒（需字母顶级域）', W.validateDomain('192.168.1.1').ok === false);

console.log('\n[7] 来源列取值');
eq('空值按自定义', W.normalizeSource('').value, W.SOURCE_USER);
eq('内置', W.normalizeSource(' 内置 ').value, W.SOURCE_BUILTIN);
eq('英文别名 builtin', W.normalizeSource('BuiltIn').value, W.SOURCE_BUILTIN);
ok('非法来源明确报错', W.normalizeSource('未知').ok === false && W.normalizeSource('未知').reason.includes('自定义'));

console.log('\n[8] 序列化细节与容量上限');
eq('备注含逗号时加引号', W.csvCell('a,b'), '"a,b"');
eq('备注含双引号时转义', W.csvCell('say "hi"'), '"say ""hi"""');
eq('普通域名不加引号（与导出一致）', W.csvCell('example.com'), 'example.com');
ok('文件大小上限 2MB', W.MAX_FILE_BYTES === 2 * 1024 * 1024);
ok('数据行上限 5000', W.MAX_DATA_ROWS === 5000);

console.log('\n----------------------------------------');
console.log('通过 ' + passed + ' 项，失败 ' + failed + ' 项');
if (failed) process.exit(1);
console.log('全部通过：模板与导入识别规则一致，可直接交付。\n');
