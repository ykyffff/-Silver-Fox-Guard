// 验证「编码自适应」解码逻辑：UTF-8 → GB18030 回退，并用扩展自身的解析器实测
const fs = require('fs');
require('../lib/allowlistCsv.js');
const W = global.SF.allowlistCsv;

// 与 ui/options.js 中的 decodeBytes 保持一致
function decodeBytes(buf) {
  const bytes = new Uint8Array(buf);
  try {
    return { text: new TextDecoder('utf-8', { fatal: true }).decode(bytes), enc: 'UTF-8' };
  } catch (e) {}
  for (const enc of ['gb18030', 'gbk']) {
    try {
      const t = new TextDecoder(enc, { fatal: true }).decode(bytes);
      if (t.indexOf('\ufffd') < 0) return { text: t, enc: enc.toUpperCase() };
    } catch (e) {}
  }
  return { text: new TextDecoder('utf-8').decode(bytes), enc: '' };
}

let pass = 0, fail = 0;
function t(name, cond, extra) {
  if (cond) { pass++; console.log('  OK   ' + name); }
  else { fail++; console.log('  FAIL ' + name + (extra ? ' -> ' + extra : '')); }
}

const cases = [
  ['C:/Users/Administrator/Desktop/silverfox-allowlist-import.csv', 'UTF-8', '桌面 UTF-8 版'],
  ['C:/Users/Administrator/Downloads/silverfox-allowlist-import.csv.gbk.bak', 'GB18030', 'Downloads GBK 版（Excel 另存的样本，.gbk.bak）'],
];

for (const [p, wantEnc, label] of cases) {
  if (!fs.existsSync(p)) { console.log('  SKIP ' + label + '（文件不存在）'); continue; }
  console.log('\n=== ' + label + ' ===');
  const d = decodeBytes(fs.readFileSync(p));
  t('编码识别为 ' + wantEnc, d.enc === wantEnc, d.enc);
  t('无替换字符', d.text.indexOf('\ufffd') < 0);
  const parsed = W.parse(d.text);
  t('CSV 解析无错误: ' + (parsed.error || '无'), !parsed.error);
  const recs = parsed.records.filter((r) => !W.isBlankRow(r.cells));
  const m = W.mapHeader(recs[0].cells);
  t('表头识别: ' + (m.error || 'OK'), !m.error);
  const rows = recs.slice(1);
  t('数据行 ' + rows.length + ' 条', rows.length > 0);
  const bad = rows.filter((r) => !W.validateDomain(r.cells[m.idx.domain]).ok);
  t('域名全部通过校验', bad.length === 0, bad.length + ' 条失败');
  const srcs = [...new Set(rows.map((r) => W.normalizeSource(r.cells[m.idx.source] || '').value))];
  console.log('  来源取值:', srcs.join('/'));
}

console.log('\n通过 ' + pass + ' / 失败 ' + fail);
process.exit(fail ? 1 : 0);
