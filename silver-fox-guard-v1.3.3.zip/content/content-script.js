// ============================================================================
// 内容脚本：根据后台判定渲染「官网」浮标或「疑似钓鱼」覆盖层，并上报页面信号
// 新增页面侧信号：51.LA 追踪、搜索引擎来源、可执行文件下载（银狐常用投递方式）
// ============================================================================
(function () {
  const ROOT_ID = '__silverfox_root__';
  let lastVerdict = null;
  let execDetected = false;

  function getRoot() {
    let el = document.getElementById(ROOT_ID);
    if (!el) {
      el = document.createElement('div');
      el.id = ROOT_ID;
      el.style.all = 'initial';
      document.documentElement.appendChild(el);
    }
    return el;
  }

  function clear() {
    const el = document.getElementById(ROOT_ID);
    if (el) el.innerHTML = '';
  }

  function applyVerdict(v) {
    if (!v) return;
    lastVerdict = v;
    clear();
    if (v.level === 'official') showOfficialBadge(v);
    else if (v.level === 'suspicious') { showOverlay(v, false); if (execDetected) showDownloadWarning(v); }
    else if (v.level === 'phishing') { showOverlay(v, true); if (execDetected) showDownloadWarning(v); }
    // safe 不渲染任何元素
  }

  // 官网认证浮标
  function showOfficialBadge(v) {
    const root = getRoot();
    const badge = document.createElement('div');
    badge.className = 'sf-badge-official';
    badge.innerHTML = '<span class="sf-dot"></span> 官方认证站点' + (v.brand ? ' · ' + v.brand : '');
    root.appendChild(badge);
  }

  // 疑似/高危覆盖层（页面内醒目提示条）
  function showOverlay(v, isPhishing) {
    const root = getRoot();
    const bar = document.createElement('div');
    bar.className = 'sf-overlay ' + (isPhishing ? 'sf-phishing' : 'sf-suspicious');
    const title = isPhishing ? '⚠ 高危钓鱼网站' : '⚠ 疑似钓鱼网站';
    const reasons = (v.reasons || []).slice(0, 4).join('；');
    bar.innerHTML =
      '<div class="sf-ov-title">' + title + '</div>' +
      '<div class="sf-ov-sub">风险分 ' + (v.score || 0) + '/100' + (v.brand ? ' · 仿冒目标：' + v.brand : '') + '</div>' +
      '<div class="sf-ov-reasons">' + (reasons || '该站点命中多项钓鱼特征') + '</div>' +
      '<div class="sf-ov-actions">' +
        '<a class="sf-btn sf-leave" href="javascript:history.back()">返回安全页</a>' +
        '<a class="sf-btn sf-ignore" id="sf-ignore">我已了解风险，继续访问</a>' +
      '</div>';
    root.appendChild(bar);
    const ignore = bar.querySelector('#sf-ignore');
    if (ignore) {
      ignore.addEventListener('click', (e) => {
        e.preventDefault();
        bar.style.display = 'none';
      });
    }
  }

  // 可执行文件下载强告警（银狐木马常借 exe/msi 投递）
  function showDownloadWarning(v) {
    const root = getRoot();
    const bar = document.createElement('div');
    bar.className = 'sf-download-warn';
    bar.innerHTML =
      '<span class="sf-dw-icon">⛔</span>' +
      '<span>该页面提供 <b>可执行文件下载</b>，而当前站点被判定为' +
      (v.level === 'phishing' ? '高危钓鱼' : '疑似钓鱼') +
      '。请勿下载或运行，以免感染银狐木马。</span>' +
      '<a class="sf-btn sf-ignore" id="sf-dw-ignore">仍要查看</a>';
    root.appendChild(bar);
    const ig = bar.querySelector('#sf-dw-ignore');
    if (ig) ig.addEventListener('click', (e) => { e.preventDefault(); bar.style.display = 'none'; });
  }

  // 监听后台推送的判定
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'verdict') applyVerdict(msg.verdict);
  });

  // 兜底：主动请求一次（解决脚本注入与导航时序问题）
  chrome.runtime.sendMessage({ type: 'requestVerdict' }, (v) => { if (v) applyVerdict(v); });

  // -------- 页面信号检测与上报 --------

  // 1) 51.LA 追踪检测（银狐仿冒页常埋固定统计 ID）
  function detect51La() {
    let id = null;
    const scripts = Array.from(document.scripts || []);
    const inline = scripts.map((s) => s.textContent || '').join('\n');
    const srcs = scripts.map((s) => s.src || '').join('\n');
    const hay = inline + '\n' + srcs;
    if (hay.indexOf('51.la') === -1 && hay.indexOf('LA.init') === -1) return false;
    // 提取 ID：js.users.51.la/<id>.js 或 LA.init({id:"<id>"})
    let m = hay.match(/js\.users\.51\.la\/([A-Za-z0-9]+)\.js/);
    if (!m) m = hay.match(/LA\.init\(\{[^}]*id:\s*["']([^"']+)/);
    if (m) id = m[1];
    chrome.runtime.sendMessage({ type: 'contentReport', tracker51la: { present: true, id } }).catch(() => {});
    return true;
  }

  // 2) 搜索引擎来源（document.referrer）
  function detectSearchReferrer() {
    const ref = document.referrer || '';
    if (!ref) return;
    const SE = ['google.', 'bing.', 'baidu.', 'sogou.', 'so.com', 'yahoo.', 'duckduckgo.', 'yandex.', 'ask.'];
    if (SE.some((h) => ref.indexOf(h) !== -1)) {
      chrome.runtime.sendMessage({ type: 'contentReport', fromSearch: true }).catch(() => {});
    }
  }

  // 3) 可执行文件下载检测
  const EXEC_EXT = ['exe', 'msi', 'bat', 'cmd', 'scr', 'js', 'vbs', 'ps1', 'dll', 'com', 'jar',
    'cab', 'msix', 'appx', 'lnk', 'reg', 'wsf', 'hta', 'sys', 'ocx'];
  function isExecHref(href) {
    if (!href) return false;
    const u = href.split('?')[0].split('#')[0];
    return EXEC_EXT.some((e) => u.toLowerCase().endsWith('.' + e));
  }
  function detectExecDownload() {
    if (execDetected) return;
    const links = Array.from(document.links || []);
    const hit = links.some((a) => isExecHref(a.href) || a.hasAttribute('download'));
    if (hit) {
      execDetected = true;
      chrome.runtime.sendMessage({ type: 'contentReport', execDownload: true }).catch(() => {});
      // 若已有高风险判定，立即展示下载告警
      if (lastVerdict && (lastVerdict.level === 'phishing' || lastVerdict.level === 'suspicious')) {
        showDownloadWarning(lastVerdict);
      }
    }
  }

  // 登录表单检测（原有）
  function detectLoginForm() {
    const hasLoginForm = !!(
      document.querySelector('input[type="password"]') ||
      document.querySelector('form[action*="login"]') ||
      document.querySelector('form[action*="signin"]')
    );
    if (hasLoginForm) {
      chrome.runtime.sendMessage({ type: 'contentReport', hasLoginForm: true }).catch(() => {});
    }
  }

  function runDetect() {
    detect51La();
    detectSearchReferrer();
    detectExecDownload();
    detectLoginForm();
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') runDetect();
  else window.addEventListener('DOMContentLoaded', runDetect);
  // 延迟再扫一次（SPA / 动态注入的下载按钮）
  setTimeout(runDetect, 1500);

  // 拦截下载点击：高风险页尝试下载 exe 时再次提示
  document.addEventListener('click', (e) => {
    const a = e.target && e.target.closest && e.target.closest('a[href]');
    if (a && isExecHref(a.getAttribute('href')) && lastVerdict &&
        (lastVerdict.level === 'phishing' || lastVerdict.level === 'suspicious')) {
      // 不阻断（尊重用户选择），仅确保告警可见
      if (!document.querySelector('.sf-download-warn')) showDownloadWarning(lastVerdict);
    }
  }, true);
})();

// ============================================================================
// 搜索结果页官网/钓鱼标注模块
// 在 Bing/百度/Google/搜狗/360/duckduckgo 的结果条目标题旁注入徽章：
//   ✓ 已验证官方（绿） | ⚠ 高危钓鱼（红） | ⚠ 疑似仿冒（橙）
// ============================================================================
(function () {
  const SE_SUFFIXES = ['bing.com', 'baidu.com', 'google.com', 'google.com.hk',
    'sogou.com', 'so.com', 'duckduckgo.com', 'yandex.com'];
  const OWN_HOSTS = new Set(SE_SUFFIXES);

  function isSearchPage() {
    const h = location.hostname.toLowerCase();
    return OWN_HOSTS.has(h) || OWN_HOSTS.has(h.replace(/^www\./, '')) ||
      SE_SUFFIXES.some((s) => h === s || h.endsWith('.' + s));
  }
  if (!isSearchPage()) return;

  // 各引擎结果标题链接选择器（通用兜底：h2/h3 内的锚点）
  const SELECTORS = [
    '#b_results li.b_algo h2 a',                      // Bing
    '#content_left h3 a',                             // 百度
    'div.g a[href^="http"] h3, a[href^="http"] > h3', // Google
    '.vrwrap h3 a, .rb h3 a, .struct2017 h3 a',       // 搜狗
    '.res-list h3 a, li.res-list h3 a',               // 360
    'a[data-testid="result-title-a"], article h2 a'   // DuckDuckGo
  ];

  function collectResultAnchors() {
    const found = new Set();
    for (const sel of SELECTORS) {
      let nodes;
      try { nodes = document.querySelectorAll(sel); } catch (e) { continue; }
      nodes.forEach((n) => found.add(n.closest('a') || n));
      if (found.size) break; // 命中第一个引擎选择器即停
    }
    // 通用兜底：h2/h3 直接包含的 http 锚点（覆盖引擎改版）
    if (!found.size) {
      document.querySelectorAll('h2 a[href^="http"], h3 a[href^="http"]').forEach((a) => found.add(a));
    }
    return [...found].filter((a) => {
      if (!a || a.dataset.sfDone) return false;
      let host;
      try { host = new URL(a.href).hostname.toLowerCase(); } catch (e) { return false; }
      if (!host || OWN_HOSTS.has(host) || host.endsWith('.' + location.hostname)) return false;
      // 百度跳转链（/link?url=）真实域名未知，跳过（由导航判定兜底保护）
      if (/^www\.baidu\.com$/.test(host) && /\/link\?/.test(a.href)) return false;
      return true;
    });
  }

  function hostOf(anchor) {
    try { return new URL(anchor.href).hostname.toLowerCase(); } catch (e) { return ''; }
  }

  function injectBadge(anchor, level, brand) {
    const badge = document.createElement('span');
    badge.textContent = level === 'official'
      ? '✓ 已验证官方' + (brand ? ' · ' + brand : '')
      : (level === 'phishing' ? '⚠ 高危钓鱼' : '⚠ 疑似仿冒');
    badge.className = 'sf-search-badge sf-lv-' + level;
    badge.title = level === 'official'
      ? '银狐猎手：该域名命中内置官方白名单'
      : '银狐猎手：' + (level === 'phishing' ? '该站点命中多项钓鱼特征，请勿输入账号密码或下载文件' : '该站点存在仿冒特征，请谨慎访问');
    badge.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); }, false);
    const h = anchor.querySelector('h2, h3') || anchor;
    h.appendChild(badge);
    anchor.dataset.sfDone = '1';
  }

  let scanTimer = null;
  function scan() {
    const anchors = collectResultAnchors();
    if (!anchors.length) return;
    const byHost = {};
    for (const a of anchors) {
      const h = hostOf(a);
      if (h) (byHost[h] = byHost[h] || []).push(a);
    }
    const hosts = Object.keys(byHost);
    if (!hosts.length) return;
    try {
      chrome.runtime.sendMessage({ type: 'CHECK_HOSTS', hosts }, (res) => {
        if (!res || !res.ok || !res.results) return;
        for (const h of hosts) {
          const v = res.results[h];
          if (!v || v.level === 'safe') { byHost[h].forEach((a) => { a.dataset.sfDone = '1'; }); continue; }
          if (v.level === 'official' || v.level === 'phishing' || v.level === 'suspicious') {
            byHost[h].forEach((a) => injectBadge(a, v.level, v.brand));
          }
        }
      });
    } catch (e) { /* 扩展上下文失效时静默 */ }
  }

  function scheduleScan() {
    if (scanTimer) return;
    scanTimer = setTimeout(() => { scanTimer = null; scan(); }, 300);
  }

  scan();
  const mo = new MutationObserver(scheduleScan);
  mo.observe(document.body || document.documentElement, { childList: true, subtree: true });
})();
