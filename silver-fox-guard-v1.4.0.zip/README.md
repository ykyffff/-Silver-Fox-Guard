# 银狐猎手 · Silver Fox Guard

> Microsoft Edge（Chromium 内核）浏览器扩展，用于实时识别 **银狐（Silver Fox）** 等组织的钓鱼网站。
> 采用「**规则引擎 + 可插拔免费 AI 研判**」双引擎，对访问网址进行实时风险识别与分级，
> 对确认的安全官网自动打上 **「官网」标签**，对疑似/高危钓鱼网站弹出 **醒目风险警示 / 全屏拦截页**。

---

## 一、核心功能模块

| 模块 | 文件 | 职责 |
|------|------|------|
| 编排中枢 | `background/service-worker.js` | 拦截导航、跑判定流水线、动态拦截规则、角标、消息协同 |
| 判定引擎 | `lib/scoring.js` | 汇总各信号 → 风险分 → 四级分类 |
| URL 解析 | `lib/urlAnalyzer.js` | 域名/TLD/协议、punycode 同形异义解码、敏感路径识别 |
| 品牌相似度 | `lib/domainSimilarity.js` | 与品牌库比对，发现仿冒域名（银狐核心手法） |
| 威胁情报 | `lib/threatIntel.js` + `data/*` | 白/黑名单、品牌库、TLD 风险库 |
| WHOIS 轻量查询 | `lib/whoisLite.js` | RDAP 域名注册天数（新注册加权） |
| AI 研判 | `lib/aiClassifier.js` | 调用任意 OpenAI 兼容端点（OpenCode/本地模型/免费 API） |
| 内容脚本 | `content/content-script.js` | 官网浮标、疑似覆盖层、登录表单上报 |
| 弹出页 | `ui/popup.html/js` | 当前页实时判定、理由、手动放行/拉黑 |
| 全屏警示页 | `ui/warning.html/js` | 高危钓鱼拦截页（返回 / 仍然访问） |
| 设置页 | `ui/options.html/js` | AI/WHOIS 开关、用户规则管理 |
| DNR 规则 | `rules/blocklist_rules.json` | 超高风险域名的硬阻断（可选） |

---

## 二、判定逻辑（风险评分表）

判定在**主框架导航**时触发，综合以下信号累加（0–100 封顶）。规则设计借鉴了银狐专用扩展 **NoFox · 银狐钓鱼站拦截** 的成熟经验（结构性判定 + CNCERT 通报特征 + 公开 IOC）。

### 参考 NoFox 学到的核心规则
- **第一层·结构性判定（不依赖清单，对任何软件有效）**：品牌名 + 营销词（`下载/破解/free/crack/pc`…）、同形字母仿冒（`mlcrosoft`、`g00gle`、`arnazon`、`micorsoft`）、中文域名 punycode 解码、高风险后缀。
- **第二层·CNCERT 通报特征**（439 个银狐域名统计）：后缀高度集中于 `.hl.cn`(42.6%) / `.com.cn`(30.8%) / `.cn`(23.2%)；命名模板复用（`zh/cn/apps/web/office` + 字母重复/错拼如 `wpps`）；拼接错位式命名（`kn-wps.com.cn`、`www-wps-cn.com`、`mb-google-chrome.hl.cn`）；页面埋 51.LA 统计（固定 ID）。
- **第三层·公开 IOC**：CNCERT / 360 Netlab 披露的控制端与投递链域名。

### 评分信号

| 信号 | 加分 | 说明 |
|------|------|------|
| 命中官方白名单 | 直接判 **官方** | 来自 `data/allowlist.json` / 用户放行 |
| 命中钓鱼黑名单 / 硬 IOC | 直接判 **高危(100)** | 来自 `data/blocklist.json` / 用户拉黑 |
| 同形字母 / 字母调换 / 字母重复 | +60 | `mlcrosoft`/`g00gle`/`arnazon`/`wpps`（硬证据，命中即拦） |
| 同形片段嵌在长域名中 | +60 | `paypa1-secure.top`、`micros0ft-update.top`：滑窗比对发现品牌同形片段 |
| 品牌字母重复 + 后缀 | +60 | `wpps-download.cn`：折叠连续重复后出现品牌、原文却没有 |
| punycode / 同形异义域名 | +40 | 如 `xn--krita-...` 解码后含品牌 |
| 品牌高度相似（≥0.9） | +60 | 仿冒微信/钉钉/飞书/ToDesk… |
| 品牌近似（0.7–0.9） | +40 | |
| 含品牌关键词却非官方域 | +30 | 如 `microsoft-update.top` |
| 品牌词 + 营销/诱导词 | +35 | `krita-pc下载.com`、`minecraft-free.net` |
| 银狐高发后缀 `.hl.cn` | +40 | CNCERT 通报集中区（占样本 42.6%） |
| 银狐高发后缀 `.com.cn/.cn` + 品牌词 | +20 | |
| 拼接错位命名（`-` 拆拼 + 高发后缀） | +25 | `kn-wps.com.cn`、`mb-google-chrome.hl.cn` |
| 命名模板标签（`zh/cn/apps/web/office…`） | +15 | |
| 页面 51.LA 追踪（非官方域） | +20（已知恶意 ID +40） | 银狐仿冒页常埋固定统计 ID |
| 高风险 TLD | +8~25 | `.top/.xyz/.click/.shop/.vip…`（`data/tld_risk.json`） |
| 敏感路径 | +15 | login/verify/下载/客服/支付… |
| 长随机子域名 | +15 | `aebf123.xxx.top` |
| IP 直连做主机 | +35 | |
| 敏感页未用 HTTPS | +20 | |
| 搜索引擎来源（结合其它异常） | +15 | 银狐站多仅放行搜索流量 |
| 可执行文件下载（结合异常） | +10 | 银狐常用 exe/msi 投递 |
| 域名注册 <30 天 | +20 | 依赖 RDAP（默认关） |
| AI 判钓鱼 | +30 | 仅灰色区间触发 |
| AI 判疑似 | +15 | |
| AI 判官方 | −30 | |

**分级阈值（借鉴 NoFox「必须有结构异常才拦」以减少误杀）**：
- **高危（拦截）**：风险分 ≥ 60 **且**存在结构异常（同形/拼接错位/punycode/CNCERT 集中后缀/已知恶意 51.LA/品牌+营销词/IP 直连等）。
- **疑似（告警）**：风险分 ≥ 30（页面内警示条，可继续）。
- **官方**：白名单命中，或品牌极高相似(≥0.95)。
- **安全**：其余。

> 说明：品牌高相似度本身**不**单独构成结构异常，需叠加其它异常才拦截——避免误杀 `microsoftsupport.com` 这类正常站。处理方式可在设置页切换「直接拦截 / 只告警」。

**品牌匹配的四个防误配机制**（用 Top 1M 真实站点回归后加固）：
- **词元边界包含**：品牌必须在域名中作为独立词元出现（`krita-pc-download` ✓、`twitch` 里的 `itch` ✗），避免 `weather.com` 被判成 EA。
- **剥 TLD + 编辑距离门控**：模糊匹配只在主体上比、且长度 ≥6、编辑距离 ≤1（长域名 ≤2），避免 `ups.com↔wps.com` 算出 0.845。
- **同形品牌校正**：模糊相似度在同形域上易选错品牌（`g00gle-verify.top` 可能被配成 Affinity），引擎会做品牌库级同形扫描，命中即用同形品牌覆盖。
- **UGC 平台豁免**：`github.io`、`vercel.app`、`blogspot.com` 等平台上不按“域名含品牌词”判仿冒，改由页面内容信号判断。

---

## 三、用户交互界面

- **工具栏角标**：绿「官网」/ 绿「✓」/ 黄「!」/ 红「⚠」，一眼识别当前站风险。
- **弹出页**：点击图标查看风险分、命中理由、仿冒目标，可一键「标记为安全 / 拉黑此站」。
- **官网浮标**：确认官网时，页面右下角显示绿底「官方认证站点 · 品牌名」浮动标签。
- **疑似覆盖层**：页面顶部红/黄警示条，列明风险理由，提供「返回安全页 / 仍继续访问」。
- **全屏拦截页**：高危钓鱼直接拦截到扩展内警示页，阻断恶意脚本执行，提供「返回安全页 / 仍访问（风险自负）」。
- **设置页 · 白名单管理（④）**：可视化表格浏览全部内置官方域名（只读），支持按域名/备注搜索、新增自定义放行、删除自定义项、导出 CSV；改动经 `RELOAD_INTEL` 实时热加载，无需重载扩展。
- **设置页 · 拦截日志（⑦）**：记录每次判定结果与命中理由，最多 200 条，支持导出 CSV / 清空。

---

## 四、后台检测 ↔ 前端提示 协同流程

```
用户发起导航
   │
   ▼
webNavigation.onBeforeNavigate (主框架, 非扩展页)
   │  analyze(url)
   │    ├─ 等待情报载入 → 解析 URL / 品牌相似度 / TLD / punycode
   │    ├─ 命中白/黑名单 → 直接定级
   │    ├─ 灰区且启用 AI → 调用可插拔 AI 二次研判
   │    └─ scoring.evaluate → {level, score, reasons}
   │
   ├─ 更新工具栏角标
   ├─ 写入 pending（供弹出页/内容脚本读取）
   └─ 若 PHISHING：
         ├─ 写入 DNR 动态重定向规则 → 浏览器在提交前跳到警示页（无闪烁、不执行恶意脚本）
         └─ 登记 phishingPending（兜底）
   │
   ▼
页面提交 onCommitted
   ├─ 非钓鱼：把判定推送给内容脚本 → 渲染「官网浮标 / 疑似覆盖层」
   └─ 钓鱼（DNR 未命中时兜底）：tab 重定向到警示页
   │
   ▼
内容脚本 (document_idle)
   ├─ 主动 requestVerdict → 后台返回 pending
   ├─ 官方 → 显示浮标；疑似/钓鱼 → 显示覆盖层
   └─ 检测登录表单 → 上报后台（可升级“安全→疑似”）
```

**防御纵深**：DNR 提交前拦截（首选，零闪烁）+ onCommitted 兜底重定向 + 内容脚本覆盖层，三层保证钓鱼站不被静默打开。

---

## 五、安装（Edge 加载解压扩展）

1. 打开 Edge → 地址栏输入 `edge://extensions`。
2. 左下角打开 **「开发人员模式」**。
3. 点击 **「加载解压缩的扩展」**，选择本项目根目录（含 `manifest.json` 的文件夹）。
4. 固定扩展图标，访问网页即可见角标与警示。
> 提交 Edge 外接程序商店时需打包为 `.zip`；本地调试用「加载解压缩」即可。

---

## 六、接入免费 AI（推荐 OpenCode Zen Free / 本地模型 / 免费 API）

默认 **规则引擎优先，AI 关闭**。设置页已内置「AI 供应商预设」下拉，选 `OpenCode Zen Free` 即可一键填好端点和默认模型。

### 推荐：OpenCode Zen Free（免费、OpenAI 兼容）
- Base URL：`https://opencode.ai/zen/v1`
- 聊天补全端点：`https://opencode.ai/zen/v1/chat/completions`（扩展已默认填入）
- 默认模型：`deepseek-v4.1-flash-free`（当前综合最佳免费档；其他如 `glm-5.3-flash-free`、`mimo-v2.6-flash-free`、`nemotron-3.5-lightning-free`、`flint-40b-free`、`beam-free` 等同属 `-free` 免费档）
- API Key：需在 `opencode.ai/auth` 获取后填入（免费档偶有调用限制，若返回 403 FreeTierError 可换用其他免费端点或本地模型）
- 启用步骤（扩展「设置」页）：
  1. 在「AI 供应商预设」选 **OpenCode Zen Free**（自动填好端点与模型）。
  2. 勾选 **启用 AI 研判**。
  3. 填入你的 OpenCode API Key。
  4. 触发区间默认 35–85（仅规则落入灰色区间才调 AI，省 token、降延迟）。

### 其他可选端点
- Ollama 本地：`http://localhost:11434/v1/chat/completions`（模型如 `llama3`，零隐私外泄）
- 硅基流动：`https://api.siliconflow.cn/v1/chat/completions`
- 通义千问：`https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions`
- 智谱 GLM：`https://open.bigmodel.cn/api/paas/v4/chat/completions`

> 免费服务 API Key 多可留空或自填；支持 JSON 模式（response_format=json_object）时建议勾选以提升稳定性。

AI 接收的特征与输出格式见 `lib/aiClassifier.js`，返回 `{"verdict","confidence","reason"}` 后由评分器叠加。

---

## 七、情报更新

- 品牌库：`data/brands.json`（242 条，含 A/B 级）；白名单：`data/allowlist.json`（**805 条**官方域名）；黑名单：`data/blocklist.json`；TLD 风险：`data/tld_risk.json`。
- **白名单三种写法**：`example.com`（含所有子域）、`=example.com`（**仅本域**，用于 `github.io` 这类 UGC 平台）、`*.example.com`（通配子域）。
- **为什么不是“高流量站全内置”**：用 NetAPI Top 1M 清单做过一次全量评估（`netapi_判定报告.md`），100 万条里确认为品牌/机构官网并内置的只有 324 条；其余是媒体、电商、政府、论坛、成人、赌博、CDN、镜像等第三方站点。整表塞进白名单会让 `OFFICIAL` 标签贬值，且会放行 UGC 平台用户子域（如 `钓鱼页.github.io`）。
- 公开黑名单（如 PhishTank `verified_online.json`）可转换为上述结构后放入 `data/blocklist.json`，重载扩展生效。
- 用户手动放行/拉黑的域名存于 `chrome.storage.local`，与内置情报自动合并，可在设置页 ④/⑤ 可视化增删。
- 改完数据后建议回归：在上一级目录执行 `node _selftest.js`（77 个代表性用例，覆盖官方/正常站/钓鱼三类）。

---

## 八、文件结构

```
silver-fox-guard/
├─ manifest.json
├─ blocklist_rules.json                # DNR 静态规则（根目录，规避 Edge 校验器子目录解析缺陷）
├─ background/service-worker.js
├─ content/{content-script.js, content-style.css}
├─ lib/{util,urlAnalyzer,domainSimilarity,threatIntel,whoisLite,scoring,aiClassifier,store,allowlistCsv}.js
├─ ui/{popup,warning,options}.{html,js,css}
├─ data/{brands,allowlist,blocklist,tld_risk}.json
├─ icons/icon{16,48,128}.png
└─ tools/{make_icons.py, test_allowlist_csv.js}
```

---

## 九、白名单批量导入（CSV 模板规范）

设置页「④ 白名单管理」提供 **下载 CSV 模板** 与 **批量导入**。模板生成与导入解析共用 `lib/allowlistCsv.js` 的同一份字段定义（`FIELDS` / `HEADER` / `csvCell`），因此下载的模板必定可被识别；本页「导出 CSV」得到的文件也可直接改完再导回。设置页内的「CSV 字段规范」表格由 `FIELDS` 动态生成，说明与解析规则永不脱节。

### 文件规格

| 项 | 要求 |
|---|---|
| 编码 | UTF-8，建议带 BOM（模板默认带 BOM；无 BOM 亦可识别）。GBK/GB18030（Excel「另存为 CSV」的默认 ANSI 格式）由导入器自动识别转码，无需手动另存 |
| 分隔符 | 英文逗号 `,`；含逗号/双引号/换行的字段用双引号包裹，字段内双引号写成 `""` |
| 换行 | `LF` 或 `CRLF` 均可 |
| 首行 | 表头，固定为 `域名,来源,备注`（按表头名识别，允许列顺序不同、可选列缺省） |
| 容量 | 单文件 ≤ 2 MB，数据行 ≤ 5000 行 |
| 空行 | 自动跳过 |

### 字段定义（顺序即 CSV 列顺序）

| 顺序 | 字段名 | 必填 | 数据格式 | 示例值 | 与现有白名单字段的对应关系 |
|---|---|---|---|---|---|
| 1 | 域名 | **必填** | 标准域名：字母/数字/点/连字符 + 至少 2 位字母顶级域；可带 `http(s)://` 前缀或路径（导入时自动剥离并转小写）；不支持端口、`*.` 通配、`=` 精确前缀 | `example.com` | `sf_state_v1.userAllow[]` 元素（规范化后的域名字符串） |
| 2 | 来源 | 可选 | 枚举 `自定义` / `内置`；留空按 `自定义` 处理；标注 `内置` 的行为只读情报，导入时跳过 | `自定义` | 无（仅用于判定是否跳过；自定义项统一写入 `userAllow`） |
| 3 | 备注 | 可选 | 任意文本；含逗号/双引号时用双引号包裹并转义 | `公司官网` | `sf_state_v1.userAllowNotes[域名]`（仅用于表格展示与导出，不参与域名匹配；留空时表格显示「（自定义）」） |

> **数据结构兼容说明**：`userAllow` 保持为**纯域名字符串数组**，未引入任何新字段，不影响 `service-worker.js` 的 `reloadIntel()` 合并逻辑与 `SF.threatIntel.matchList()` 匹配行为。

### 模板内容示例

下载的文件 `silverfox-allowlist-template.csv`（UTF-8 BOM + 表头 + 3 行**可直接导入**的示例数据，导入前请替换或删除示例行）：

```csv
域名,来源,备注
example.com,自定义,"示例：公司官网（导入前请替换或删除本行）"
oa.example.cn,自定义,示例：办公系统
partner.example.org,自定义,
```

### 导入行为

- **格式校验**：文件类型/大小/编码、CSV 引号闭合、表头是否含「域名」列、逐行域名合法性、来源枚举取值。表头识别失败会明确提示改用 UTF-8 编码或下载官方模板。
- **重复数据处理**：文件内重复、已在自定义白名单、已被内置白名单覆盖、来源标注「内置」的行统一跳过并分类计数，其余行正常导入；与「手动拉黑」冲突的行给出提醒但不阻断（与手动添加行为一致）。
- **错误提示**：逐行列出「CSV 第 N 行：原因」（最多显示 20 条），单行失败不影响其它行。
- **结果反馈**：成功 / 跳过 / 失败三类计数 + 跳过原因分组 + 错误明细 + 备注保存说明；提供「仅校验（不写入）」模式用于导入前预检。
- **生效流程**：单次写入 `chrome.storage.local` → 发送 `RELOAD_INTEL` 热加载情报 → 刷新白名单表格，与现有添加/删除流程完全一致。

### 自测

```bash
node tools/test_allowlist_csv.js
```

覆盖模板往返一致性、与现有导出格式兼容、BOM/CRLF、引号转义、表头别名、域名校验、来源枚举等 54 项断言。

---

## 十、免责声明

本工具为**防御性安全辅助**，判定基于启发式规则与可选项 AI，存在误报/漏报可能。
请勿将其作为唯一安全依据；涉及资金、账号的操作务必通过官方渠道二次确认。
作者不对因依赖本工具导致的任何损失负责。
