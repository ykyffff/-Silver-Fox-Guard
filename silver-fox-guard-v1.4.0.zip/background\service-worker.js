// ============================================================================
// 银狐猎手 · 后台 Service Worker
// 职责：拦截导航 → 运行判定流水线 → 高危动态拦截到警示页 → 更新角标 → 协同内容脚本
// ============================================================================
// importScripts 的路径是相对「本 worker 脚本所在目录」解析的：
// 本文件位于 background/，而 lib/ 在扩展根目录，因此必须使用 ../lib/
importScripts(
  '../lib/util.js',
  '../lib/urlAnalyzer.js',
  '../lib/domainSimilarity.js',
  '../lib/threatIntel.js',
  '../lib/whoisLite.js',
  '../lib/icpChecker.js',        // ICP 备案查询
  '../lib/featureEngine.js',     // 增强特征提取
  '../lib/scoring.js',
  '../lib/homoglyph.js',
  '../lib/aiClassifier.js',
  '../lib/store.js'
);

const LEVELS = SF.scoring.LEVELS;

// 每个标签当前判定（最新一次）
const pending = new Map();           // tabId -> verdict
// 每个标签的判定 Promise（供内容脚本按需拉取，解决时序问题）
const tabPromise = new Map();        // tabId -> Promise<verdict>
// 本次会话临时放行（用户点击“仍然访问”后写入）
const allowOnce = new Set();
// 判定缓存（10 分钟 TTL）
const verdictCache = new Map();

const DATA_FILES = {
  brands: 'data/brands.json',
  blocklist: 'data/blocklist.json',
  allowlist: 'data/allowlist.json',
  tldRisk: 'data/tld_risk.json'
};

// 内置情报（与用户规则分离，便于合并）
let builtin = { blocklist: [], allowlist: [], brands: [], tldRisk: {} };
let dataReady = loadData();

async function loadData() {
  const results = {};
  for (const [k, p] of Object.entries(DATA_FILES)) {
    try {
      const r = await fetch(chrome.runtime.getURL(p));
      results[k] = await r.json();
    } catch (e) {
      results[k] = null;
      console.warn('[SilverFox] 加载数据失败:', p, e);
    }
  }
  builtin = {
    blocklist: results.blocklist || [],
    allowlist: results.allowlist || [],
    brands: results.brands || [],
    tldRisk: results.tldRisk || {}
  };
  await reloadIntel();
}

// 合并「内置情报 + 用户规则」后载入威胁情报引擎
async function reloadIntel() {
  const s = await SF.store.get();
  const blocklist = builtin.blocklist.concat(
    (s.userBlock || []).map((d) => ({ domain: d, note: '用户拉黑' }))
  );
  const allowlist = builtin.allowlist.concat(
    (s.userAllow || []).map((d) => ({
      domain: d,
      note: (s.userAllowNotes && s.userAllowNotes[d]) || '用户放行'
    }))
  );
  SF.threatIntel.load({
    blocklist, allowlist,
    brands: builtin.brands,
    tldRisk: builtin.tldRisk
  });
}

function isExtensionUrl(url) {
  return url.startsWith('chrome-extension://') || url.startsWith('edge-extension://') || url.startsWith('about:') || url.startsWith('chrome://');
}

// 核心：判定单个 URL
async function analyze(url, tabId) {
  await dataReady; // 确保内置情报已载入
  if (allowOnce.has(url)) return null;
  if (verdictCache.has(url)) return verdictCache.get(url);

  const parsed = SF.urlAnalyzer.parse(url);
  if (!parsed) return null;

  const brands = SF.threatIntel.getBrands();
  const brandMatch = SF.domainSimilarity.bestMatch(parsed.host, brands);

  let whoisAge = null;
  const cfg = await SF.store.getConfig();
  if (cfg.whois && cfg.whois.enabled) {
    whoisAge = await SF.whoisLite.ageInDays(parsed.host);
  }

  // 增强：提取特征（失败绝不阻断主判定流水线）
  let features = null;
  try {
    features = await SF.featureEngine.extractFeatures(url, brands, null, cfg.icp, brandMatch.brand);
  } catch (e) {
    console.warn('[SilverFox] 特征提取失败（已降级为纯规则）:', e);
  }

  // 第一遍：纯规则 + 特征
  let verdict = SF.scoring.evaluate({ parsed, brandMatch, whoisAgeDays: whoisAge, aiVerdict: null, features });
  verdict.url = url;
  verdict.host = parsed.host;
  verdict.brandScore = brandMatch.score;
  verdict.whoisAgeDays = whoisAge;
  verdict.features = features;

  // 灰色区间且启用 AI → 调 AI 二次研判
  const ai = cfg.ai || {};
  if (ai.enabled && verdict.score >= (ai.minScore || 35) && verdict.score < (ai.maxScore || 85)) {
    const aiRes = await SF.aiClassifier.classify({
      url, host: parsed.host, tld: parsed.tld, isIp: parsed.isIp, punycode: parsed.punycode,
      brand: brandMatch.brand, brandScore: brandMatch.score, score: verdict.score, reasons: verdict.reasons,
      features // 传递增强特征给 AI
    }, ai);
    if (aiRes && !aiRes.error && aiRes.verdict) {
      verdict = SF.scoring.evaluate({ parsed, brandMatch, whoisAgeDays: whoisAge, aiVerdict: aiRes, features });
      verdict.url = url;
      verdict.host = parsed.host;
      verdict.brandScore = brandMatch.score;
      verdict.ai = aiRes;
    }
  }

  verdictCache.set(url, verdict);
  setTimeout(() => verdictCache.delete(url), 10 * 60 * 1000);
  return verdict;
}

function updateBadge(tabId, v) {
  const map = {
    official: { text: '官网', color: '#1a7f37' },
    safe: { text: '✓', color: '#1a7f37' },
    suspicious: { text: '!', color: '#b58105' },
    phishing: { text: '⚠', color: '#c0392b' }
  };
  const m = map[v.level] || map.safe;
  chrome.action.setBadgeText({ tabId, text: m.text });
  chrome.action.setBadgeBackgroundColor({ tabId, color: m.color });
}

// 构建警示页 URL（携带原始网址、标签与规则 ID）
function buildWarningUrl(url, tabId, id) {
  return chrome.runtime.getURL('ui/warning.html') +
    '?url=' + encodeURIComponent(url) + '&tab=' + tabId + '&id=' + id;
}

// 高危钓鱼：优先用 DNR 动态规则在页面提交前重定向到警示页（无闪烁、不执行恶意脚本）
// 同时登记到 phishingPending，由 onCommitted 兜底（防 DNR 竞态漏拦截）
const phishingPending = new Map(); // tabId -> { url, id }
let ruleIdSeq = 100000;            // 动态规则自增 ID（启动时已清空旧规则，避免冲突）

async function blockWithWarning(url, tabId) {
  const id = ++ruleIdSeq;
  phishingPending.set(tabId, { url, id });
  try {
    const warnUrl = buildWarningUrl(url, tabId, id);
    // 过滤串以 | 锚定在“协议之后的主机边界”，避免误伤 other-evil.com 等兄弟域名；
    // 无路径时补斜杠，避免 evil.com 误匹配 evil.com.evil2.com
    let f = url.split('?')[0].replace(/^https?:\/\//, '');
    if (f.indexOf('/') === -1) f += '/';
    const rule = {
      id,
      priority: 1,
      action: { type: 'redirect', redirect: { url: warnUrl } },
      condition: { urlFilter: '|' + f, resourceTypes: ['main_frame'] }
    };
    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: [rule] });
  } catch (e) {
    console.warn('[SilverFox] 动态拦截规则写入失败，依赖 onCommitted 兜底:', e);
  }
}

// 每个标签已收集到的页面侧信号（51.LA / 搜索来源 / 可执行下载）
const tabExtra = new Map(); // tabId -> { tracker51la, fromSearch, execDownload }

// 拦截日志（仅本机）
function pushLog(v) {
  const actionMap = { official: '官网', safe: '放行', suspicious: '告警', phishing: '拦截' };
  SF.store.pushLog({
    t: Date.now(),
    action: v.level,
    actionText: actionMap[v.level] || v.level,
    host: v.host,
    codes: (v.codes || []).join(' '),
    reasons: (v.reasons || []).join('；')
  }).catch(() => {});
}

// 内容脚本上报信号后，基于已有判定复算（叠加页面侧特征）
async function reanalyze(tabId, extraPartial) {
  const v = pending.get(tabId);
  if (!v || !v.url) return;
  const cfg = await SF.store.get();
  const mode = (cfg.config && cfg.config.mode) || 'block';
  const parsed = SF.urlAnalyzer.parse(v.url);
  if (!parsed) return;
  const brands = SF.threatIntel.getBrands();
  const brandMatch = SF.domainSimilarity.bestMatch(parsed.host, brands);
  const extra = Object.assign({}, tabExtra.get(tabId) || {}, extraPartial);
  tabExtra.set(tabId, extra);
  let verdict = SF.scoring.evaluate({ parsed, brandMatch, whoisAgeDays: v.whoisAgeDays, aiVerdict: v.ai, extra });
  verdict.url = v.url; verdict.host = parsed.host; verdict.brandScore = brandMatch.score; verdict.ai = v.ai;
  if (mode === 'warn' && verdict.level === LEVELS.PHISHING) verdict.level = LEVELS.SUSPICIOUS;
  const escalated = verdict.level === LEVELS.PHISHING && v.level !== LEVELS.PHISHING;
  pending.set(tabId, verdict);
  updateBadge(tabId, verdict);
  SF.store.bumpStats(verdict.level);
  chrome.tabs.sendMessage(tabId, { type: 'verdict', verdict }).catch(() => {});
  if (escalated && mode === 'block') {
    await blockWithWarning(verdict.url, tabId);
  }
  if (escalated) pushLog(verdict);
}

// ---- 导航事件 ----
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;            // 仅处理主框架
  if (isExtensionUrl(details.url)) return;      // 跳过扩展自身页面
  const tabId = details.tabId;
  const p = analyze(details.url, tabId).then(async (v) => {
    if (!v) return null;
    const cfg = await SF.store.get();
    const mode = (cfg.config && cfg.config.mode) || 'block';
    if (mode === 'warn' && v.level === LEVELS.PHISHING) v.level = LEVELS.SUSPICIOUS;
    pending.set(tabId, v);
    updateBadge(tabId, v);
    SF.store.bumpStats(v.level);
    pushLog(v);
    if (v.level === LEVELS.PHISHING && mode === 'block') {
      await blockWithWarning(details.url, tabId);
    }
    return v;
  });
  tabPromise.set(tabId, p);
});

// 页面提交后：推送判定给内容脚本；若 DNR 未能拦截钓鱼，则在此兜底重定向到警示页
chrome.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId !== 0) return;
  if (isExtensionUrl(details.url)) {
    phishingPending.delete(details.tabId); // 已进入扩展页，清除标记
    return;
  }
  const v = pending.get(details.tabId);
  if (v && v.level !== LEVELS.PHISHING) {
    chrome.tabs.sendMessage(details.tabId, { type: 'verdict', verdict: v }).catch(() => {});
    return;
  }
  // 兜底：DNR 未命中时，重定向到警示页（warning.html 自身不会进入此分支，避免死循环）
  const ph = phishingPending.get(details.tabId);
  if (ph && details.url.indexOf('warning.html') === -1) {
    phishingPending.delete(details.tabId);
    chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [ph.id] }).catch(() => {});
    chrome.tabs.update(details.tabId, { url: buildWarningUrl(ph.url, details.tabId, ph.id) }).catch(() => {});
  }
});

// ---- 消息中心 ----
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 内容脚本请求当前标签判定（兜底推送）
  if (msg.type === 'requestVerdict') {
    const tabId = sender.tab && sender.tab.id;
    const p = tabId != null ? tabPromise.get(tabId) : null;
    if (p) {
      p.then((v) => sendResponse(v || null));
      return true; // 异步响应
    }
    sendResponse(pending.get(tabId) || null);
    return;
  }

  // 内容脚本上报页面信号（登录表单 / 51.LA 追踪 / 搜索来源 / 可执行下载）
  if (msg.type === 'contentReport') {
    const tabId = sender.tab && sender.tab.id;
    if (tabId == null) { sendResponse({ ok: true }); return; }

    // 登录表单：命中品牌但原本判安全 → 升级为疑似
    if (msg.hasLoginForm) {
      const v = pending.get(tabId);
      if (v && v.level === LEVELS.SAFE && v.brand) {
        v.level = LEVELS.SUSPICIOUS;
        v.score = Math.max(v.score, 45);
        v.reasons = v.reasons || [];
        v.reasons.push('页面含登录表单且域名近似品牌，已升级为疑似');
        pending.set(tabId, v);
        updateBadge(tabId, v);
        chrome.tabs.sendMessage(tabId, { type: 'verdict', verdict: v }).catch(() => {});
      }
    }

    // 51.LA 追踪 / 搜索来源 / 可执行下载：合并信号后复算
    const partial = {};
    if (msg.tracker51la) partial.tracker51la = msg.tracker51la;
    if (msg.fromSearch) partial.fromSearch = true;
    if (msg.execDownload) partial.execDownload = true;
    if (Object.keys(partial).length) {
      reanalyze(tabId, partial);
    }
    sendResponse({ ok: true });
    return;
  }

  // 用户从警示页点击“仍然访问”
  if (msg.type === 'proceed') {
    allowOnce.add(msg.url);
    chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [msg.id] }).catch(() => {});
    chrome.tabs.update(msg.tab, { url: msg.url }).catch(() => {});
    sendResponse({ ok: true });
    return;
  }

  // 弹出页请求某标签的判定
  if (msg.type === 'getVerdictForTab') {
    const v = pending.get(msg.tabId) || null;
    sendResponse(v);
    return;
  }

  // 弹出页/设置页：用户手动放行或拉黑
  if (msg.type === 'userAllow' || msg.type === 'userBlock') {
    handleUserRule(msg.type, msg.host).then((r) => sendResponse(r));
    return true;
  }

  // 设置页：读取内置白名单（用于可视化浏览，内置条目只读）
  if (msg.type === 'GET_BUILTIN_ALLOWLIST') {
    sendResponse({ ok: true, allowlist: builtin.allowlist || [] });
    return;
  }

  // 设置页：用户规则变更后，重新合并内置+用户情报并热加载
  if (msg.type === 'RELOAD_INTEL') {
    reloadIntel().then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }

  // 搜索结果页批量判定（内容脚本注入官网/钓鱼徽章用）
  // 输入：{ hosts: ['a.com', 'b.org', ...] }  输出：{ [host]: { level, brand } }
  if (msg.type === 'CHECK_HOSTS') {
    checkHosts(Array.isArray(msg.hosts) ? msg.hosts : [])
      .then((map) => sendResponse({ ok: true, results: map }))
      .catch(() => sendResponse({ ok: false, results: {} }));
    return true; // 异步响应
  }
});

// 搜索结果页批量判定：只做规则引擎快速判定（不触发 WHOIS/AI/ICP 网络查询，保证即时返回）
async function checkHosts(hosts) {
  await dataReady;
  const out = {};
  const uniq = [...new Set(hosts.map((h) => String(h || '').toLowerCase().trim()))].filter(Boolean).slice(0, 50);
  for (const host of uniq) {
    try {
      const cacheKey = 'search::' + host;
      if (verdictCache.has(cacheKey)) { out[host] = verdictCache.get(cacheKey); continue; }
      const parsed = SF.urlAnalyzer.parse('https://' + host + '/');
      if (!parsed) continue;
      const brandMatch = SF.domainSimilarity.bestMatch(parsed.host, SF.threatIntel.getBrands());
      const v = SF.scoring.evaluate({ parsed, brandMatch, whoisAgeDays: null, aiVerdict: null });
      const brief = { level: v.level, brand: v.brand || null, score: v.score };
      out[host] = brief;
      verdictCache.set(cacheKey, brief);
      setTimeout(() => verdictCache.delete(cacheKey), 10 * 60 * 1000);
    } catch (e) { /* 单个域名失败不影响其它 */ }
  }
  return out;
}

async function handleUserRule(type, host) {
  const s = await SF.store.get();
  if (type === 'userAllow') {
    if (!s.userAllow.includes(host)) s.userAllow.push(host);
    s.userBlock = (s.userBlock || []).filter((h) => h !== host);
  } else {
    if (!s.userBlock.includes(host)) s.userBlock.push(host);
    s.userAllow = (s.userAllow || []).filter((h) => h !== host);
    // 从放行移除时同步清掉备注，避免残留脏数据
    if (s.userAllowNotes && s.userAllowNotes[host] !== undefined) delete s.userAllowNotes[host];
  }
  await SF.store.set({ userAllow: s.userAllow, userBlock: s.userBlock, userAllowNotes: s.userAllowNotes || {} });
  await reloadIntel(); // 重新合并内置 + 用户规则
  return { ok: true };
}

// 安装 / 启动时：预加载数据，并清空上一会话残留的动态拦截规则
function clearDynamicRules() {
  if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.getDynamicRules) return;
  chrome.declarativeNetRequest.getDynamicRules().then((rules) => {
    const ids = rules.map((r) => r.id);
    if (ids.length) chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ids }).catch(() => {});
  }).catch(() => {});
}

chrome.runtime.onInstalled.addListener(() => { dataReady = loadData(); clearDynamicRules(); });
chrome.runtime.onStartup.addListener(() => { dataReady = loadData(); clearDynamicRules(); });

// 每日刷新一次统计/缓存（预留：后续可在此拉取最新公开黑名单）
chrome.alarms.create('dailyRefresh', { periodInMinutes: 1440 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'dailyRefresh') {
    verdictCache.clear();
  }
});
